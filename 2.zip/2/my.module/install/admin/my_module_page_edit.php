<?
require_once($_SERVER["DOCUMENT_ROOT"]."/local/modules/my.module/admin/my_module_page_edit.php");
?>