<?
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\ModuleManager;
use Bitrix\Main\Config\Option;
use Bitrix\Main\EventManager;
use Bitrix\Main\Application;
use Bitrix\Main\Entity\Base;

Loc::loadMessages(__FILE__);

class my_module extends CModule
{
    public function __construct()
    {
        if (file_exists(__DIR__ . "/version.php")) {

            $arModuleVersion = array();

            require_once(__DIR__ . "/version.php");

            $this->MODULE_VERSION = $arModuleVersion["VERSION"];
            $this->MODULE_VERSION_DATE = $arModuleVersion["VERSION_DATE"];

        }
        $this->MODULE_ID = str_replace("_", ".", get_class($this));
        $this->MODULE_NAME = 'Мой модуль';
        $this->MODULE_DESCRIPTION = 'Мой модуль';
        return false;
    }

    public function DoInstall()
    {
        global $APPLICATION;

        ModuleManager::registerModule($this->MODULE_ID);
        $this->InstallFiles();
        $this->InstallDB();

        $APPLICATION->IncludeAdminFile(
            Loc::getMessage("INSTALL_TITLE") . " \"" . Loc::getMessage("MODULE_NAME") . "\"",
            __DIR__ . "/step.php"
        );

        return false;
    }

    public function DoUninstall()
    {
        global $APPLICATION;

        $this->UnInstallFiles();
        $this->UnInstallDB();

        ModuleManager::unRegisterModule($this->MODULE_ID);

        $APPLICATION->IncludeAdminFile(
            Loc::getMessage("UNINSTALL_TITLE") . " \"" . Loc::getMessage("MODULE_NAME") . "\"",
            __DIR__ . "/unstep.php"
        );

        return false;
    }

    public function InstallFiles()
    {
        return CopyDirFiles(
            $_SERVER["DOCUMENT_ROOT"]."/local/modules/my.module/install/admin",
            $_SERVER["DOCUMENT_ROOT"]."/local/admin",
            true,
            true
        );

        /*return CopyDirFiles(
            $_SERVER["DOCUMENT_ROOT"]."/local/modules/my.module/install/admin",
            $_SERVER["DOCUMENT_ROOT"]."/bitrix/admin",
            true,
            true
        );*/
    }

    public function InstallDB()
    {
        if (\Bitrix\Main\Loader::includeModule($this->MODULE_ID)) {
            if (!Application::getConnection()->isTableExists(\MyModule\Orm\MyTable::getEntity()->getDBTableName())) {
                \MyModule\Orm\MyTable::getEntity()->createDBTable();
            }
        }
    }

    public function UnInstallFiles()
    {
        //DeleteDirFilesEx("/bitrix/admin/my_module_page.php");
        //DeleteDirFilesEx("/bitrix/admin/my_module_page_edit.php");

        DeleteDirFilesEx("/local/admin/my_module_page_edit.php");
        DeleteDirFilesEx("/local/admin/my_module_page.php");
        return true;
    }

    public function UnInstallDB()
    {
        if (\Bitrix\Main\Loader::includeModule($this->MODULE_ID)) {
            if (Application::getConnection()->isTableExists(\MyModule\Orm\MyTable::getEntity()->getDBTableName())) {
                $connection = Application::getInstance()->getConnection();
                $connection->dropTable(\MyModule\Orm\MyTable::getTableName());
            }
        }

        return false;
    }
}