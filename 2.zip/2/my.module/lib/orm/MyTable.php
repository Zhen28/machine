<?

namespace MyModule\Orm;

use Bitrix\Main\Entity\DataManager;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Entity;
use Bitrix\Main\Type\DateTime;

class MyTable extends DataManager
{
    /**
     * @return string
     */
    public static function getTableName(): string
    {
        return 'my_module_table';
    }

    /**
     * @return array
     * @throws \Bitrix\Main\SystemException
     */
    public static function getMap(): array
    {
        return [
            new Entity\IntegerField('ID', [
                'primary' => true,
                'autocomplete' => true,
                'title' => Loc::getMessage("MYMODULE_ID"),
            ]),
            new Entity\StringField('NAME', [
                'title' => Loc::getMessage("MYMODULE_NAME"),
            ]),
            new Entity\TextField('DESCRIPTION', [
                'title' => Loc::getMessage("MYMODULE_DESCRIPTION"),
            ]),
            new Entity\DateTimeField('DATE_INSERT', [
                'title' => Loc::getMessage("MYMODULE_DATE_INSERT"),
                'default_value' => new DateTime()
            ]),
            new Entity\DateTimeField('DATE_UPDATE', [
                'title' => Loc::getMessage("MYMODULE_DATE_UPDATE"),
                'default_value' => new DateTime()
            ])
        ];
    }
}