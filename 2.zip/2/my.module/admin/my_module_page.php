<?require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_before.php");?>

<?

use \MyModule\Orm\MyTable;

IncludeModuleLangFile(__FILE__);

CModule::IncludeModule("my.module");

$APPLICATION->SetTitle(GetMessage("MYMODULE"));

$cData = new MyTable;
$rsData = $cData->GetList([], $arFilter);
while($row = $rsData->fetch()){
    $rows[] = [
            'data' => $row,
            'actions' => [
                [
                    'text'    => GetMessage("MYMODULE_EDIT"),
                    'onclick' => 'document.location.href="/bitrix/admin/my_module_page_edit.php?ID='.$row['ID'].'"'
                ],
                [
                    'text'    => GetMessage("MYMODULE_DELETE"),
                    'onclick' => 'document.location.href="/bitrix/admin/my_module_page_edit.php?ID='.$row['ID'].'"'
                ],
            ]
    ];
}

$headers = [
    ['id' => 'ID', 'name' => GetMessage("MYMODULE_EL_ID"), 'sort' => 'id', 'default' => true],
    ['id' => 'NAME', 'name' => GetMessage("MYMODULE_EL_NAME"), 'sort' => 'name', 'default' => true],
    ['id' => 'DESCRIPTION', 'name' => GetMessage("MYMODULE_EL_DESCRIPTION"), 'sort' => 'description', 'default' => true],
    ['id' => 'DATE_INSERT', 'name' => GetMessage("MYMODULE_EL_DATE_INSERT"), 'sort' => 'date_insert', 'default' => true],
    ['id' => 'DATE_UPDATE', 'name' => GetMessage("MYMODULE_EL_DATE_UPDATE"), 'sort' => 'date_update', 'default' => true]
];
?>

<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_after.php");
?>

<?

$grid_options = new Bitrix\Main\Grid\Options('my_module_list');
$sort = $grid_options->GetSorting(['sort' => ['ID' => 'DESC'], 'vars' => ['by' => 'by', 'order' => 'order']]);
$nav_params = $grid_options->GetNavParams();

$nav = new Bitrix\Main\UI\PageNavigation('my_module_list');
$nav->allowAllRecords(true)
    ->setPageSize($nav_params['nPageSize'])
    ->initFromUri();
?>

<?
$aMenu = array(
    array(
        'TEXT' => GetMessage("MYMODULE_ADD"),
        'TITLE' => GetMessage("MYMODULE_ADD"),
        'LINK' => "my_module_page_edit.php",
        'ICON' => "btn_new",
    )
);
$context = new CAdminContextMenu($aMenu);
$context->Show();

$APPLICATION->IncludeComponent(
    'bitrix:main.ui.grid',
    '',
    [
        'GRID_ID' => 'my_module_list',
        'COLUMNS' => $headers,
        'ROWS' => $rows,
        'SHOW_ROW_CHECKBOXES' => true,
        'NAV_OBJECT' => $nav,
        'PAGE_SIZES' => [
            ['NAME' => "5", 'VALUE' => '5'],
            ['NAME' => '10', 'VALUE' => '10'],
            ['NAME' => '20', 'VALUE' => '20'],
            ['NAME' => '50', 'VALUE' => '50'],
            ['NAME' => '100', 'VALUE' => '100']
        ],
    ]
);
?>

<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog_admin.php");?>