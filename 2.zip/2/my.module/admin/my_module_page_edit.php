<?require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin.php");?>

<?

use \MyModule\Orm\MyTable;
use Bitrix\Main\Type\DateTime;

IncludeModuleLangFile(__FILE__);

CModule::IncludeModule("my.module");

$APPLICATION->SetTitle(GetMessage("MYMODULE").': '.($ID>0? GetMessage("MYMODULE_EL_EDIT").' '.$ID : GetMessage("MYMODULE_EL_ADD")));

$aTabs = array(
  array("DIV" => "edit", "TAB" => GetMessage("MYMODULE_EL"), "TITLE"=>GetMessage("MYMODULE_EL")),
);
$tabControl = new CAdminTabControl("tabControl", $aTabs);

$ID = intval($ID);
$message = null;
$bVarsFromForm = false;

if(
    $REQUEST_METHOD == "POST"
    &&
    ($save!="" || $apply!="")
    &&
    check_bitrix_sessid()
)
{
  $my_table = new MyTable;

  $arFields = Array(
      'ID'  => $ID,
      'NAME'    => $NAME,
      'DESCRIPTION'  => $DESCRIPTION,
      'DATE_UPDATE'  => new DateTime(),
  );

  if($ID > 0)
  {
      $arFields['DATE_INSERT'] = new DateTime();
      $res = $my_table->Update($ID, $arFields);
  }
  else
  {
    $res = $my_table->Add($arFields);
    $ID = $res->getId();
  }

  if($res)
  {
    if ($apply != "")
      LocalRedirect("/bitrix/admin/my_module_page_edit.php?ID=".$ID);
    else
      LocalRedirect("/bitrix/admin/my_module_page.php");
  }
  else
  {
    if($e = $APPLICATION->GetException())
      $message = new CAdminMessage(GetMessage("MYMODULE_EL_ERROR"), $e);
    $bVarsFromForm = true;
  }
}

$str_ID = 0;
$str_NAME = '';
$str_DESCRIPTION = '';
$str_DATE_INSERT = '';
$str_DATE_UPDATE = '';

if($ID>0)
{
  $my_table = MyTable::GetByID($ID);
  $my_table_data = $my_table->fetch();
  if($my_table_data){
      $str_ID = $my_table_data['ID'];
      $str_NAME = $my_table_data['NAME'];
      $str_DESCRIPTION = $my_table_data['DESCRIPTION'];
      $str_DATE_INSERT = $my_table_data['DATE_INSERT'];
      $str_DATE_UPDATE = $my_table_data['DATE_UPDATE'];
  }
  else{
      $ID = 0;
  }
}

if($bVarsFromForm)
  $DB->InitTableVarsForEdit("my_module_table", "", "str_");

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_after.php");

$aMenu = array(
  array(
    'TEXT' => GetMessage("MYMODULE_ELS"),
    'TITLE' => GetMessage("MYMODULE_ELS"),
    'LINK' => 'my_module_page.php',
    'ICON' => 'btn_list',
  )
);

if($ID>0)
{
  $aMenu[] = array('SEPARATOR' => true);
  $aMenu[] = array(
      'TEXT' => GetMessage("MYMODULE_ADD"),
      'TITLE' => GetMessage("MYMODULE_ADD"),
      'LINK' => "my_module_page_edit.php",
      'ICON' => "btn_new",
  );
  $aMenu[] = array(
      'TEXT' => GetMessage("MYMODULE_DELETE"),
      'TITLE' => GetMessage("MYMODULE_DELETE"),
      //'LINK' => "my_module_page_edit.php",
      'ICON' => "btn_delete",
  );
}

$context = new CAdminContextMenu($aMenu);
$context->Show();
?>

<?
if($message)
  echo $message->Show();
elseif($my_table->LAST_ERROR!="")
  CAdminMessage::ShowMessage($my_table->LAST_ERROR);
?>

<form method="POST" Action="<?echo $APPLICATION->GetCurPage()?>" ENCTYPE="multipart/form-data" name="post_form">

<?echo bitrix_sessid_post();?>
<?
$tabControl->Begin();
$tabControl->BeginNextTab();
?>
    <?if($ID>0){?>
        <tr>
            <td><?=GetMessage("MYMODULE_EL_ID")?></td>
            <td><?=$ID?><input type="hidden" name="ID" value="<?=$ID?>"></td>
        </tr>
        <tr>
            <td><?=GetMessage("MYMODULE_EL_DATE_INSERT")?></td>
            <td><?=$str_DATE_INSERT?></td>
        </tr>
        <tr>
            <td><?=GetMessage("MYMODULE_EL_DATE_UPDATE")?></td>
            <td><?=$str_DATE_UPDATE?></td>
        </tr>
    <?}?>
  <tr>
    <td width="40%"><?echo GetMessage("MYMODULE_EL_NAME")?></td>
    <td width="60%"><input type="text" name="NAME" value="<?echo $str_NAME;?>" size="30" maxlength="100"></td>
  </tr>
  <tr>
    <td><?echo GetMessage("MYMODULE_EL_DESCRIPTION")?></td>
    <td><textarea class="typearea" name="DESCRIPTION" cols="45" rows="5" wrap="VIRTUAL"><?echo $str_DESCRIPTION; ?></textarea></td>
  </tr>

<?
$tabControl->Buttons(
  array(
    "back_url"=>"my_module_page.php",
  )
);
?>

<?
$tabControl->End();
?>

<?
$tabControl->ShowWarnings("post_form", $message);
?>

<?
echo BeginNote();?>
<span class="required">*</span><?echo GetMessage("REQUIRED_FIELDS")?>
<?echo EndNote();?>
</form>

<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog_admin.php");?>