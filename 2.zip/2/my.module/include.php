<?
\Bitrix\Main\Loader::registerAutoLoadClasses(
    "my.module",
    ["\MyModule\Orm\MyTable" => "lib/orm/MyTable.php"]
);