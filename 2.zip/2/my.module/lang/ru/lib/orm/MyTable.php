<?
$MESS["MYMODULE_ID"] = "ID";
$MESS["MYMODULE_NAME"] = "Заголовок";
$MESS["MYMODULE_DESCRIPTION"] = "Описание";
$MESS["MYMODULE_DATE_INSERT"] = "Дата добавления";
$MESS["MYMODULE_DATE_UPDATE"] = "Дата изменения";