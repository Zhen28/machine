<?
$MESS["STEP_BEFORE"] = "Модуль";
$MESS["STEP_AFTER"] = "установлен";
$MESS["STEP_SUBMIT_BACK"]   = "Вернуться в список";