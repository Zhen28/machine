<?
$MESS["UNSTEP_BEFORE"] = "Модуль";
$MESS["UNSTEP_AFTER"] = "удален";
$MESS["UNSTEP_SUBMIT_BACK"] = "Вернуться в список";