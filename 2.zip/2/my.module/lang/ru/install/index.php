<?
$MESS["MODULE_NAME"] = "Мой модуль";
$MESS["MODULE_DESCRIPTION"]  = "Мой модуль";
$MESS["INSTALL_TITLE"]  = "Установка модуля";
$MESS["UNINSTALL_TITLE"]  = "Деинсталляция модуля";