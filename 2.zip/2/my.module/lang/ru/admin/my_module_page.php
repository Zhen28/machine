<?
$MESS["MYMODULE"] = "Мой модуль";
$MESS["MYMODULE_EL_ID"] = "ID";
$MESS["MYMODULE_EL_NAME"] = "Заголовок";
$MESS["MYMODULE_EL_DESCRIPTION"] = "Описание";
$MESS["MYMODULE_EL_DATE_INSERT"] = "Дата добавления";
$MESS["MYMODULE_EL_DATE_UPDATE"] = "Дата изменения";
$MESS["MYMODULE_EDIT"] = "Редактировать";
$MESS["MYMODULE_DELETE"] = "Удалить";
$MESS["MYMODULE_ADD"] = "Добавить";
